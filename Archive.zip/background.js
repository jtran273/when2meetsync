console.log('Background service worker loaded.');
// Future background tasks can be implemented here.
